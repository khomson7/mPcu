<?php

namespace tests\_fixtures;

use yii\test\ActiveFixture;

class UserFixture extends ActiveFixture
{
    public $modelClass = 'dektrium\user\models\User';
}
